package utils;

import java.net.URI;

public class EndPoints {
    public static final String heroEndPoint="heroes";
}
